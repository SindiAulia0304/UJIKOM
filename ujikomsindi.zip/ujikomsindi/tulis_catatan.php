<div clas="card">
<div class="card-header">
<a href ="user.php" class=" btn-dark btn-icon-split">
<span class="icon text-white-50">
<i class="fa fa-arrow-left"></i>
</span>
<span class="text">kembali</span>
</a>
</div>
<div class="card-body">
     <form action="simpan_catatan.php" method="post">
          
<div class="form-group row">
     <label class="col-sm-2 col-form-label">Pilih Tanggal</label>
     <div class="col-sm-3">
          <input name="tanggal" type="date" id="txtDate" min=<?php echo date("Y-m-d");?>"required class="form-control placeholder="Masukkan Tanggal">
     </div>
</div>
<div class="form-group row">
     <label class="col-sm-2 col-form-label">Pilih Jam</label>
     <div class="col-sm-3">
          <input name="jam" type="time" required class="form-control" placeholder="Masukkan Jam">
     </div>
</div>
<div class="form-group row">
     <label class="col-sm-2 col-form-label">Pilih Lokasi</label>
     <div class="col-sm-3">
          <input name="lokasi" type="text" required class="form-control" placeholder="Masukkan Lokasi">
     </div>
</div>
<div class="form-group row">
     <label class="col-sm-2 col-form-label">Suhu Tubuh</label>
     <div class="col-sm-3">
          <input name="suhu" type="text"  required class="form-control" placeholder="Masukkan Suhu Tubuh">
     </div>
</div>
<div class="form-group">
     <button type="submit"class="btn btn-info"><i class="fa fa-save"></i>SIMPAN</button>
     <button type="submit"class="btn btn-danger"><i class="fa fa-trash"></i>KOSONGKAN</button>
</div>
</form>
</div>
</div>