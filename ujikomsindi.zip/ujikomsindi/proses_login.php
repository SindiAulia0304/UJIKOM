<?php

$nik         =$_POST['nik'];
$nama_lengkap =$_POST['nama_lengkap'];

$format = "$nik|$nama_lengkap";
$file =file('config.txt',FILE_IGNORE_NEW_LINES);
if(in_array($format, $file)){// jika data ditemukan 
session_start();
$_SESSION['nik'] = $nik;
echo "<h3>".$SESSION['nama_lengkap']."</h3>";

header("location:user.php");

}else{ // jika data tidak ditemukan ?>
<script type="text/javascript"> window
alert('!!! maaf kombinasi NIK dan Nama Lengkap salah.');
window.location.assign('index.php');
</script>
<?php }